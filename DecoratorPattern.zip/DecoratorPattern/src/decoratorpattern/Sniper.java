package decoratorpattern;

public class Sniper extends Weapon {

    public Sniper() {
        description = "Sniper Gun ";
    }

    @Override
    public double weight() {
        return 5.4;
    }

    @Override
    public int ammo() {
        return 10;
    }

    @Override
    public double damage() {
        return 80;
    }

    @Override
    public double price() {
        return 1000;
    }

}
