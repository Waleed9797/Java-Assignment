package decoratorpattern;

public class M16 extends Weapon {

    public M16() {
        description = "M16 Gun";
    }

    @Override
    public double weight() {
        return 3.4;
    }

    @Override
    public int ammo() {
        return 20;
    }

    @Override
    public double damage() {
        return 43;
    }

    @Override
    public double price() {
        return 500;
    }

}
