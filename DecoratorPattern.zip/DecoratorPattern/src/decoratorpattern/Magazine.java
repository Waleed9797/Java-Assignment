package decoratorpattern;

public class Magazine extends WeaponAccessory {

    Weapon weapon;

    public Magazine(Weapon weapon) {
        this.weapon = weapon;
    }

    @Override
    public String getDescription() {
        return weapon.getDescription() + ", Magazine";
    }

    @Override
    public double weight() {
        return 1 + weapon.weight();
    }

    @Override
    public int ammo() {
        return 0;

    }

    @Override
    public double damage() {
        return 0;
    }

    @Override
    public double price() {
        return 60;
    }
}
