package decoratorpattern;

public class Silencer extends WeaponAccessory {

    Weapon weapon;

    public Silencer(Weapon weapon) {
        this.weapon = weapon;
    }

    @Override
    public String getDescription() {
        return weapon.getDescription() + ", Silencer";
    }

    @Override
    public double weight() {
        return 0.3 + weapon.weight();
    }

    @Override
    public double price() {
        return 100;
    }

    @Override
    public int ammo() {
        return 0;
    }

    @Override
    public double damage() {
        return 0;
    }

}
