package decoratorpattern;

public class SingltonDecoratorTest {

    public static void main(String[] args) {

        Player waleed = Player.getInstance();
        System.out.println(waleed);

        waleed.pickUpWeapon();
        Weapon gun = new Sniper();
        System.out.println("Weapon Weight: " + gun.weight() + "kg");
        System.out.println("Weapon Ammo: " + gun.ammo() + " bulits");
        System.out.println("Weapon Damage: " + gun.damage());
        System.out.println("Weapon Price: " + "£" + gun.price());

    }

}
