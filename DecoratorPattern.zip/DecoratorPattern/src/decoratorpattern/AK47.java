package decoratorpattern;

public class AK47 extends Weapon {

    public AK47() {
        description = "AK47 Gun";
    }

    @Override
    public double weight() {
        return 3.50;
    }

    @Override
    public int ammo() {
        return 30;
    }

    @Override
    public double damage() {
        return 40;
    }

    @Override
    public double price() {
        return 800;
    }
}
