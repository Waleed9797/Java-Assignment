package decoratorpattern;

public class M4 extends Weapon {

    public M4() {
        description = "M4 Gun";
    }

    @Override
    public double weight() {
        return 3.5;

    }

    @Override
    public int ammo() {
        return 30;

    }

    @Override
    public double damage() {
        return 50;
    }

    @Override
    public double price() {
        return 700;
    }

}
