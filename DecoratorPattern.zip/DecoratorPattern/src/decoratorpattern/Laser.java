package decoratorpattern;

public class Laser extends WeaponAccessory {

    Weapon weapon;

    public Laser(Weapon weapon) {
        this.weapon = weapon;
    }

    @Override
    public String getDescription() {
        return weapon.getDescription() + ", Laser";

    }

    @Override
    public double weight() {
        return 0.2 + weapon.weight();
    }

    @Override
    public int ammo() {
        return 0;
    }

    @Override
    public double damage() {
        return 43;
    }

    @Override
    public double price() {
        return 30;
    }

}
