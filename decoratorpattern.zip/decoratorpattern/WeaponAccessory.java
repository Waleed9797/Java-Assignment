package decoratorpattern;

public abstract class WeaponAccessory extends Weapon {

    @Override
    public abstract String getDescription();

}
