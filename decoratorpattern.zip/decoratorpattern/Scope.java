package decoratorpattern;

public class Scope extends WeaponAccessory {

    Weapon weapon;

    public Scope(Weapon weapon) {
        this.weapon = weapon;
    }

    @Override
    public String getDescription() {
        return weapon.getDescription() + ", Scope";
    }

    @Override
    public double weight() {
        return 0.5 + weapon.weight();
    }

    @Override
    public int ammo() {
        return 0;

    }

    @Override
    public double damage() {
        return 0;
    }

    @Override
    public double price() {
        return 150;
    }
}
