package decoratorpattern;

public class Mp5 extends Weapon {

    public Mp5() {
        description = "MP5 Gun";
    }

    @Override
    public double weight() {
        return 6.8;
    }

    @Override
    public int ammo() {
        return 30;
    }

    @Override
    public double damage() {
        return 40;
    }

    @Override
    public double price() {
        return 650;
    }

}
