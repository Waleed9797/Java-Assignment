package decoratorpattern;

public abstract class Weapon {

    String description = "Unknown Weapon";

    public String getDescription() {
        return description;

    }

    public abstract double weight();

    public abstract int ammo();

    public abstract double damage();

    public abstract double price();

}
