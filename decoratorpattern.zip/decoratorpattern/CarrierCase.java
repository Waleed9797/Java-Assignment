package decoratorpattern;

public class CarrierCase extends WeaponAccessory {

    Weapon weapon;

    public CarrierCase(Weapon weapon) {
        this.weapon = weapon;
    }

    @Override
    public String getDescription() {
        return weapon.getDescription() + ", CarrierCase";
    }

    @Override
    public double weight() {
        return 0.7 + weapon.weight();
    }

    @Override
    public int ammo() {
        return 0;

    }

    @Override
    public double damage() {
        return 0;
    }

    @Override
    public double price() {
        return 50;
    }
}
