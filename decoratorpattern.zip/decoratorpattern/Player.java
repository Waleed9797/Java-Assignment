package decoratorpattern;

public class Player {

    private static Player playa;
//    private Weapon weapon;

    private Player() {
        System.out.println("Player Created");
    }
//getinstance method. is used to diclare the variables. it has to be static 

    public static Player getInstance() {
        if (playa == null) {
            playa = new Player();
        }
        return playa;
    }

    public void pickUpWeapon() {
        System.out.println("First Weapon - no extras");
        Weapon weapon = new M4();
        System.out.println(weapon.getDescription() + " " + weapon.weight());

        System.out.println("Second Weapon - with extras");
        Weapon weapon2 = new Mp5();
        weapon2 = new Magazine(weapon2);
        weapon2 = new Silencer(weapon2);
        weapon2 = new Scope(weapon2);
        weapon2 = new Laser(weapon2);
        System.out.println(weapon2.getDescription() + " " + weapon2.weight());
    }

}
